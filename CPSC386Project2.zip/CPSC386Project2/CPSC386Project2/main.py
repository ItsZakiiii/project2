from player import Player
from game_stats import GameStats
from enemy import *
from camera import Camera
from stage_manager import StageManager
from score import Score
from gameover import GameoverScreen
from hud import HUD
from settings import Settings
import game_functions as gf



FPS = 60
def play():
    pygame.init()
    settings = Settings()
    window = pygame.display.set_mode((768, 672), 0, 32)  # window
    screen = pygame.Surface((settings.scr_width, settings.scr_height))  # real game
    pygame.display.set_caption("Mario")
    stats = GameStats()
    main_clock = pygame.time.Clock()
    go = GameoverScreen(screen=window)
    cs = Score(screen=window)
    camera = Camera(screen=screen)
    sm = StageManager(screen=screen, settings=settings, stats=stats)
    hud = HUD(screen=window, settings=settings, stats=stats, stage_manager=sm)
    pc = Player(screen=screen, settings=settings, stats=stats, stage_manager=sm, camera=camera, hud=hud)
    sm.load_stage(stage=stats.current_stage, hud=hud)


    while True:
        # scales the game to the right resolution
        resized = pygame.transform.scale(screen, (800, 700))
        window.blit(resized, (0, 0))
        gf.check_inputs(player=pc)

        if stats.current_stage < stats.credits_stage and stats.current_stage != -1:
            camera.update(pc)
        if stats.current_stage != -1:
            gf.update_player(player=pc, platforms=sm.platforms, enemies=sm.enemies, warp_zones=sm.warp_zones)
            sm.update(player=pc)

        if stats.current_stage != -1:
            screen.fill(settings.bg_color)
            sm.draw(camera)
            pc.draw1()

        if stats.current_stage < stats.credits_stage and stats.current_stage != -1:
            hud.draw()
        elif stats.current_stage == stats.credits_stage:
            cs.draw()
        elif stats.current_stage == -1:
            go.draw()
        pygame.display.update()
        main_clock.tick(60)


play()
