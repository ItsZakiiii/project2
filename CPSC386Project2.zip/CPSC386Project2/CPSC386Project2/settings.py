class Settings:
    def __init__(self):
        self.bg_color = (150, 150, 250)
        self.scr_width = 256
        self.scr_height = 224
        self.bullet_limit = 5
