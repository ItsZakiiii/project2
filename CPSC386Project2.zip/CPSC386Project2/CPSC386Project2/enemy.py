import pygame
from pygame.sprite import Sprite
from timer import Timer
from pygame.font import Font

# Add fire stick with boss tag and deleted (re: 'return' only) die function
'''
Fire stick is a list of images
coordinates are based off of sin and cos values for current angle
multiple coefficients by the radius of each fireball
'''


def load(image):
    return pygame.image.load(image)


class Enemy(Sprite):
    def __init__(self, screen, settings, frames, point, left, bot):
        super().__init__()
        self.tag = 'enemy'
        self.screen = screen
        self.settings = settings
        self.anim = Timer(frames)
        self.rect = frames[0].get_rect()
        self.rect.x = left
        self.rect.bottom = bot
        self.x = float(self.rect.x)
        self.y = float(self.rect.y)
        self.point = point
        self.dead = False
        self.font = Font(None, 16)
        self.point_text = self.font.render(str(self.point), True, (255, 255, 255), self.settings.bg_color)
        self.point_rect = self.point_text.get_rect()
        self.point_rect.center = self.rect.center
        self.point_time = 1000
        self.point_start_time = 0

    def changeframes(self, frames):
        self.anim = Timer(frames)
        self.rect = frames[0].get_rect()

    def changetag(self, tag):
        self.tag = tag

    def changewait(self, wait):
        self.anim.wait = wait

    def set_pos(self, left, bot):
        self.rect.x = left
        self.rect.y = bot
        self.x = float(self.rect.x)
        self.y = float(self.rect.y)

    # General functionality called gethit that updates enemy logic based on state
    def hit(self, player):
        pass

    def die(self):
        self.dead = True
        self.point_start_time = pygame.time.get_ticks()

    def update(self, player, sprites, enemies):
        if self.dead:
            if pygame.time.get_ticks() - self.point_start_time >= self.point_time:
                self.kill()

    def draw(self, camera):
        if self.dead:
            image = self.point_text
        else:
            image = self.anim.imagerect()
        self.screen.blit(image, camera.apply(self))


class Goomba(Enemy):
    def __init__(self, screen, settings, left, bot, altframes=False):
        self.screen = screen
        self.screen_rect = screen.get_rect()
        if not altframes:
            self.frames = [pygame.image.load('images/enemy/goomba1.bmp'),
                           pygame.image.load('images/enemy/goomba2.bmp')]
        else:
            self.frames = [load('images/Enemies/74.png'), load('images/Enemies/75.png')]
        super().__init__(screen=screen, settings=settings, frames=self.frames, point=100, left=left, bot=bot)

        self.is_grounded = False
        self.chasing_player = False
        self.speed = .5
        self.gravity = 0.3
        self.vely = 0
        self.m_dangerous = True
        self.e_dangerous = False

    def update(self, player, sprites, enemies):
        super().update(player, sprites, enemies)

        # check falling off
        if self.rect.y > self.screen_rect.height:
            self.kill()

        # gravity
        if not self.is_grounded:
            self.vely += self.gravity
            if self.vely >= 6:
                self.vely = 6
        else:
            if self.rect.x - player.rect.x < 350:
                self.chasing_player = True
            if self.chasing_player and not self.dead:
                self.x -= self.speed

        self.y += self.vely
        self.rect.x = int(self.x)
        self.rect.y = int(self.y)

        # collision
        self.is_grounded = False
        sprites_hit = pygame.sprite.spritecollide(self, sprites, False)
        if sprites_hit:
            for s in sprites_hit:
                # Enemy, ground can't be broke, brick can, pipe is pipe
                if s.tag in ['brick', 'ground', 'pipe', 'mystery', 'bridge']:
                    c = self.rect.clip(s.rect)  # collision rect
                    if c.width >= c.height:
                        if self.vely >= 0:
                            self.rect.bottom = s.rect.top + 1
                            self.y = float(self.rect.y)
                            self.is_grounded = True
                            self.vely = 0
                    if c.width < c.height:
                        self.speed *= -1
                        self.x -= self.speed
                        self.rect.x = int(self.x)

        collisions = pygame.sprite.spritecollide(self, enemies, False)
        if collisions:
            for enemy in collisions:
                if enemy != self:
                    if enemy.e_dangerous:
                        self.die()
                    else:
                        self.speed *= -1
                        self.x -= self.speed
                        self.rect.x = int(self.x)

    def hit(self, player):
        self.die()
class KoopaTroopaGreen(Enemy):
    def __init__(self, screen, settings, left, bot, altframes=False):
        self.screen = screen
        self.screen_rect = screen.get_rect()
        self.status = 'walkleft'
        self.m_dangerous = True
        self.e_dangerous = False
        self.shell_time = 0
        self.unshell_time = 0
        if not altframes:
            self.frames = {
                'walkleft': [load('images/Enemies/87.png'), load('images/Enemies/96.png')],
                'walkright': [load('images/Enemies/106.png'), load('images/Enemies/97.png')],
                'shell': [load('images/Enemies/118.png')],
                'mshell': [load('images/Enemies/118.png')],
                'unshell': [load('images/Enemies/113.png')]
            }
        else:
            self.frames = {
                'walkleft': [load('images/Enemies/89.png'), load('images/Enemies/94.png')],
                'walkright': [load('images/Enemies/99.png'), load('images/Enemies/104.png')],
                'shell': [load('images/Enemies/116.png')],
                'mshell': [load('images/Enemies/116.png')],
                'unshell': [load('images/Enemies/115.png')]
            }
        super().__init__(screen=screen, settings=settings, frames=self.frames[self.status],
                         point=200, left=left, bot=bot)

        self.is_grounded = False
        self.chasing_player = False
        self.speed = .5
        self.gravity = 0.3
        self.vely = 0

    def update(self, player, sprites, enemies):
        super().update(player, sprites, enemies)

        # check falling off
        if self.rect.y > self.screen_rect.height:
            self.kill()

        # gravity
        if not self.is_grounded:
            self.vely += self.gravity
            if self.vely >= 6:
                self.vely = 6
        else:
            if self.rect.x - player.rect.x < 350:
                self.chasing_player = True
            if self.chasing_player and not self.dead:
                if self.status != 'unshell' and self.status != 'shell':
                    self.x -= self.speed
                elif self.status == 'shell':
                    if self.shell_time == 0:
                        self.shell_time = pygame.time.get_ticks()
                    else:
                        if pygame.time.get_ticks() - self.shell_time > 7000:
                            self.status = 'unshell'
                            super().changeframes(self.frames[self.status])
                            self.shell_time = 0
                elif self.status == 'unshell':
                    if self.unshell_time == 0:
                        self.unshell_time = pygame.time.get_ticks()
                    else:
                        if pygame.time.get_ticks() - self.unshell_time > 500:
                            self.speed = 1
                            self.status = 'walkleft'
                            self.m_dangerous = True
                            super().changeframes(self.frames[self.status])
                            self.unshell_time = 0

        self.y += self.vely
        self.rect.x = int(self.x)
        self.rect.y = int(self.y)

        # collision
        self.is_grounded = False
        sprites_hit = pygame.sprite.spritecollide(self, sprites, False)
        if sprites_hit:
            for s in sprites_hit:
                # Enemy, ground can't be broke, brick can, pipe is pipe
                if s.tag in ['brick', 'ground', 'pipe', 'mystery', 'bridge']:
                    original_rect = self.rect
                    c = self.rect.clip(s.rect)  # collision rect
                    if c.width >= c.height:
                        if self.vely >= 0:
                            self.rect.bottom = s.rect.top + 1
                            self.y = float(self.rect.y)
                            self.is_grounded = True
                            self.vely = 0
                    if c.width < c.height:
                        self.rect = original_rect
                        if self.status == 'mshell':
                            self.speed *= -1
                        elif self.x < s.rect.x:
                            if self.status == 'walkright':
                                self.x -= self.speed
                                self.speed *= -1
                                self.status = 'walkleft'
                        else:
                            if self.status == 'walkleft':
                                self.x += self.speed
                                self.speed *= -1
                                self.status = 'walkright'
                        super().changeframes(self.frames[self.status])

        if self.status == 'mshell':
            return

        collisions = pygame.sprite.spritecollide(self, enemies, False)
        if collisions:
            for enemy in collisions:
                if enemy != self:
                    if enemy.e_dangerous and not self.e_dangerous:
                        self.die()
                    else:
                        self.x += self.speed
                        if self.rect.x < enemy.rect.x:
                            if self.status != 'walkleft':
                                self.speed *= -1
                                self.status = 'walkleft'
                        else:
                            if self.status != 'walkright':
                                self.speed *= -1
                                self.status = 'walkright'
                        super().changeframes(self.frames[self.status])

    def hit(self, player):
        _ = player
        if self.status == 'walkright' or self.status == 'walkleft':
            self.status = 'shell'
            self.speed = 0
            self.m_dangerous = False
            super().changeframes(self.frames[self.status])
        elif self.status == 'shell':
            self.status = 'mshell'
            self.speed = 3
            self.m_dangerous = True
            self.e_dangerous = True
            super().changeframes(self.frames[self.status])
        elif self.status == 'mshell' or self.status == 'unshell':
            self.m_dangerous = False
            self.e_dangerous = False
            self.die()